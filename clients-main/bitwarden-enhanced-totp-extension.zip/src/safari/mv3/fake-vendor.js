// Empty file set for the Safari build process for mv3 to ensure backwards compatibility with mv2.
// Will be removed once we fully migrate Safari to mv3.
