// FIXME: Remove when updating file. Eslint update
// eslint-disable-next-line @typescript-eslint/no-require-imports
require("./menu-container.scss");

import { AutofillInlineMenuContainer } from "./autofill-inline-menu-container";

(() => new AutofillInlineMenuContainer())();
