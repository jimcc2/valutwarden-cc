export const Fido2PortName = {
  InjectedScript: "fido2-injected-content-script-port",
} as const;
