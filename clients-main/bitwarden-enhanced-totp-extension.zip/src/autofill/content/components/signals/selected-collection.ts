import { signal } from "@lit-labs/signals";

export const selectedCollection = signal<string>("0");
