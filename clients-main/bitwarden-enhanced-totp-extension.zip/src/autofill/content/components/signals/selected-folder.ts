import { signal } from "@lit-labs/signals";

export const selectedFolder = signal<string>("0");
