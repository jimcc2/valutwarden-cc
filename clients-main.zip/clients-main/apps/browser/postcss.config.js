/* eslint-disable @typescript-eslint/no-require-imports */
module.exports = {
  plugins: [
    require("postcss-import"),
    require("postcss-nested"),
    require("tailwindcss"),
    require("autoprefixer"),
  ],
};
