import { Component } from "@angular/core";

@Component({
  selector: "popup-footer",
  templateUrl: "popup-footer.component.html",
  imports: [],
})
export class PopupFooterComponent {}
